
/**
 * trieda obsahuje main metodu programu kde spusti GUI pre uzivatela
 * 
 * @author Dominik Bubeník
 */
public class Main {

    private static HraciaPlocha hp;

    public static void main(String[] args) {
        Vystup v = new Vystup();
    }

}
